<template>
  <div>
    <button>登录</button> / <button>注册</button>
  </div>
</template>
