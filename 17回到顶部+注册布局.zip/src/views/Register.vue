<template>
  <div class="container">
    <header class="header">注册</header>
    <div class="content">
      <van-cell-group>
        <van-field
          v-model="username"
          required
          clearable
          label="用户名"
          :right-icon="usernameicon"
          placeholder="请输入用户名"
          :error-message="usernamestate"
        />

        <van-field
          v-model="password"
          center
          type="password"
          label="密码"
          clearable
          placeholder="请输入密码"
          error-message="passwordstate"
          required
        >
          <van-icon slot="button" size="24px" color="success" name="passed"></van-icon>
        </van-field>
        <van-field
          v-model="sms"
          center
          clearable
          label="短信验证码"
          placeholder="请输入短信验证码"
          error-message="验证码错误"
          required
        >
          <van-button slot="button" size="small" type="primary">发送验证码</van-button>
        </van-field>
      </van-cell-group>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      username: '',
      password: '',
      sms: ''
    }
  },
  computed: {
    usernameicon () {
      if (this.username === '') {
        return ''
      } else if (this.username.length !== 11) {
        return ''
      } else {
        return 'passed'
      }
    },
    usernamestate () {
      if (this.username === '') {
        return ''
      } else if (this.username.length !== 11) {
        return '手机号格式错误'
      } else {
        return ''
      }
    }
  }
}
</script>
