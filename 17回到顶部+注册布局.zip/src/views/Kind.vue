<template>
  <div class="container">
    <header class="header">分类头部</header>
    <div class="content">
      <van-tabs >
        <van-tab title="标签 1">内容 1</van-tab>
        <van-tab title="标签 2">内容 2</van-tab>
        <van-tab title="标签 3">内容 3</van-tab>
        <van-tab title="标签 4">内容 4</van-tab>
      </van-tabs>
    </div>
  </div>
</template>

<script>
export default {
  mounted () {
    // console.log(this.$router)
    // console.log(this.$route)
  }
}
</script>
