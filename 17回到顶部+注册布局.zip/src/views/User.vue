<template>
  <div class="container">
    <header class="header">个人中心头部</header>
    <div class="content">
      <router-view></router-view>
      <div>其余的内容</div>
    </div>
  </div>
</template>

<script>
export default {
  // mounted () {
  //   if (localStorage.getItem('islogin') === 'ok') {
  //     this.$router.push('/user/login')
  //   } else {
  //     this.$router.push('/user/nologin')
  //   }
  // }
}
</script>
