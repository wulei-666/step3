<template>
  <div class="container">
    <header class="header">首页头部</header>
    <div class="content" id="content">
      <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore">
        <div class="banner">
          <mt-swipe :auto="4000">
            <mt-swipe-item v-for = "(item, index) of bannerlist" :key="index">
              <img :src="item" alt="">
            </mt-swipe-item>
          </mt-swipe>
        </div>
        <Prolist :prolist="prolist"/>
      </mt-loadmore>
      <div class="backTop" v-show="flag" @click="backTop">
        <van-icon size="30px" name="upgrade" color="red"/>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import Prolist from '@/components/common/Prolist'

export default {
  data () {
    return {
      bannerlist: [],
      prolist: [],
      allLoaded: false,
      pageCode: 1,
      flag: false
    }
  },
  methods: {
    backTop () {
      document.getElementById('content').scrollTop = 0
    },
    scrollToTop () {
      var scrollTop = document.getElementById('content').scrollTop
      if (scrollTop > 200) {
        // 显示回到顶部
        this.flag = true
      } else {
        // 隐藏回到顶部
        this.flag = false
      }
      console.log(scrollTop)
    },
    loadTop () {
      axios.get('http://www.daxunxun.com/douban')
        .then(res => { // 请求成功
          console.log(res.data)
          this.allLoaded = false // 下拉刷新表示的是 可以重新开始上拉加载
          this.pageCode = 1 // 页码重置
          this.prolist = res.data
          this.$refs.loadmore.onTopLoaded()
        }).catch(err => { // 请求失败
          console.log(err)
        })
    },
    loadBottom () {
      axios.get(`http://www.daxunxun.com/douban?count=20&start=${this.pageCode * 20}`)
        .then(res => { // 请求成功
          console.log(res.data)
          if (res.data.lenght === 0) {
            this.allLoaded = true // 没有数据了
          } else {
            // 把this.prolist 和 res.data 数组合并
            this.prolist = [...this.prolist, ...res.data]
            this.pageCode++ // 页码加1
          }
          this.$refs.loadmore.onBottomLoaded()
        }).catch(err => { // 请求失败
          console.log(err)
        })
    }
  },
  components: {
    Prolist
  },
  beforeRouterLeaver (to,from,next) {
    document.getElementById('content').removeEventListener('scroll', this.scrollToTop)
    next()
  },
  mounted () {
    document.getElementById('content').addEventListener('scroll', this.scrollToTop)
    // console.log(this.$router)
    // console.log(this.$route)
    axios.get('http://www.daxunxun.com/banner')
      .then(res => { // 请求成功
        /**
        * ["/images/1.jpg"]
        ['http://www.daxunxun.com/images/1.jpg']
        */
        console.log(res.data)
        let arr = []
        res.data.map(item => {
          arr.push('http://www.daxunxun.com' + item)
        })
        console.log(arr)
        this.bannerlist = arr
      }).catch(err => { // 请求失败
        console.log(err)
      })
    axios.get('http://www.daxunxun.com/douban?count=10')
      .then(res => { // 请求成功
        console.log(res.data)
        this.prolist = res.data
      }).catch(err => { // 请求失败
        console.log(err)
      })
  }
}
</script>

<style lang="scss">
.banner {
  height: 1.9rem;
  border: 1px solid #f66;
  img {
    width: 100%;
  }
}
.backTop {
  position: fixed;
  bottom: 55px;
  right: 10px;
  width: 40px;
  height: 40px;
}
</style>
