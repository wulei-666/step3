<template>
  <div class="box">
    <div class="container">
      <van-nav-bar
        title="详情"
        left-arrow
        @click-left="back"
      />
      <div class="content">
        {{ title }} ---  {{ year }}
      </div>
    </div>
    <van-goods-action>
      <van-goods-action-mini-btn
        icon="chat-o"
        text="客服"
        @click="onClickMiniBtn"
      />
      <van-goods-action-mini-btn
        icon="cart-o"
        text="购物车"
        @click="onClickMiniBtn"
      />
      <van-goods-action-big-btn
        text="加入购物车"
        @click="onClickBigBtn"
      />
      <van-goods-action-big-btn
        primary
        text="立即购买"
        @click="onClickBigBtn"
      />
    </van-goods-action>
  </div>
</template>

<script>
import Vue from 'vue'
import axios from 'axios'
import { Toast } from 'vant'
Vue.use(Toast)
export default {
  data () {
    return {
      title: '',
      year: 0
    }
  },
  methods: {
    back () {
      this.$router.go(-1)
    },
    onClickMiniBtn () {
      Toast('点击图标')
    },
    onClickBigBtn () {
      Toast('点击按钮')
    }
  },
  mounted () {
    console.log(this.$route)
    const { id } = this.$route.params
    axios.get(`http://www.daxunxun.com/detail?id=${id}`)
      .then(res => {
        console.log(res.data)
        this.title = res.data[0].title
        this.year = res.data[0].year
      })
  }
}
</script>

<style lang="scss">
.van-nav-bar {
  background-color: #f66;
}
</style>
