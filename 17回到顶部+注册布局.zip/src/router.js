import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  mode: 'history', // url地址无需 #
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/register',
      name: 'register',
      components: {
        default: () => import('./views/Register')
      }
    },
    {
      path: '/detail/:id', // /detail/123    id只是一个变量的名字
      name: 'detail',
      components: {
        default: () => import('./views/Detail')
      }
    },
    {
      path: '/home',
      name: 'home',
      alias: '/h',
      components: {
        default: () => import('./views/Home'),
        footer: () => import('@/components/common/Footer')
      }
    },
    {
      path: '/kind',
      name: 'kind',
      components: {
        default: () => import('./views/Kind')
      }
    },
    {
      path: '/cart',
      name: 'cart',
      components: {
        default: () => import('./views/Cart'),
        footer: () => import('@/components/common/Footer')
      }
    },
    {
      path: '/user',
      name: 'user',
      components: {
        default: () => import('./views/User'),
        footer: () => import('@/components/common/Footer')
      },
      children: [
        {
          path: '',
          redirect: 'login'
        },
        {
          path: 'nologin',
          component: () => import('@/components/user/NoLogin')
        },
        {
          path: 'login',
          component: () => import('@/components/user/Login')
        }
      ]
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})
