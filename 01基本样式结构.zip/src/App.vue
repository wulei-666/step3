<template>
  <div id="app">
    <div class="container">
      <header class="header">头部</header>
      <div class="content">内容</div>
    </div>
    <footer class="footer">
      <ul>
        <li>
          <span class="iconfont icon-shouye"></span>
          <p>首页</p>
        </li>
        <li>
          <span class="iconfont icon-tubiao113"></span>
          <p>分类</p>
        </li>
        <li>
          <span class="iconfont icon-gouwuche"></span>
          <p>购物车</p>
        </li>
        <li>
          <span class="iconfont icon-weibiaoti2fuzhi12"></span>
          <p>我的</p>
        </li>
      </ul>
    </footer>
  </div>
</template>

<style lang="scss">
@import '@/lib/reset.scss';

html, body, #app {
  @include rect(100%, 100%);
}

#app {
  @include flexbox();
  @include flex-direction(column);
  .container {
    @include flex();
    @include rect(100%, auto);
    @include flexbox();
    @include flex-direction(column);
    .header {
      @include rect(100%, 0.44rem);
      @include background-color(#f66);
    }
    .content {
      @include flex();
      @include rect(100%, auto);
    }
  }
  .footer {
    @include rect(100%, 0.5rem);
    @include background-color(#efefef);
    ul {
      @include rect(100%, 100%);
      @include flexbox();
      li{
        @include flex();
        @include rect(auto, 100%);
        @include flexbox();
        @include flex-direction(column);
        @include justify-content();
        @include align-items();
        span {
          @include font-size(0.24rem);
        }
        p {
          @include font-size(0.12rem);
        }
      }
    }
  }
}
</style>
