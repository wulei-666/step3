<template>
  <footer class="footer">
    <ul>
      <li>
        <span class="iconfont icon-shouye"></span>
        <p>首页</p>
      </li>
      <li>
        <span class="iconfont icon-tubiao113"></span>
        <p>分类</p>
      </li>
      <li>
        <span class="iconfont icon-gouwuche"></span>
        <p>购物车</p>
      </li>
      <li>
        <span class="iconfont icon-weibiaoti2fuzhi12"></span>
        <p>我的</p>
      </li>
    </ul>
  </footer>
</template>
