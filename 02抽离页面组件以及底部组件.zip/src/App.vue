<template>
  <div id="app">
    <!-- <Home ></Home> -->
    <!-- <Kind /> -->
    <!-- <Cart /> -->
    <User />
    <Footer />
  </div>
</template>

<script>
// import Home from '@/views/Home'
// import Kind from '@/views/Kind'
// import Cart from '@/views/Cart'
import User from '@/views/User'
import Footer from '@/components/common/Footer'

export default {
  components: {
    // Home
    // Kind
    // Cart
    User,
    Footer
  }
}
</script>

<style lang="scss">
@import '@/lib/reset.scss';

html, body, #app {
  @include rect(100%, 100%);
}

#app {
  @include flexbox();
  @include flex-direction(column);
  .container {
    @include flex();
    @include rect(100%, auto);
    @include flexbox();
    @include flex-direction(column);
    .header {
      @include rect(100%, 0.44rem);
      @include background-color(#f66);
    }
    .content {
      @include flex();
      @include rect(100%, auto);
    }
  }
  .footer {
    @include rect(100%, 0.5rem);
    @include background-color(#efefef);
    ul {
      @include rect(100%, 100%);
      @include flexbox();
      li{
        @include flex();
        @include rect(auto, 100%);
        @include flexbox();
        @include flex-direction(column);
        @include justify-content();
        @include align-items();
        span {
          @include font-size(0.24rem);
        }
        p {
          @include font-size(0.12rem);
        }
      }
    }
  }
}
</style>
