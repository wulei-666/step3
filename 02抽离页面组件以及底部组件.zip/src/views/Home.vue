<template>
  <div class="container">
    <header class="header">首页头部</header>
    <div class="content">首页内容</div>
  </div>
</template>

<script>
export default {
}
</script>
