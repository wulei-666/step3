<template>
  <div class="container">
    <header class="header">个人中心头部</header>
    <div class="content">个人中心内容</div>
  </div>
</template>

<script>
export default {
}
</script>
